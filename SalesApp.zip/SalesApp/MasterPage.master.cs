﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class MasterPage : System.Web.UI.MasterPage
{

     protected void Page_Load(object sender, EventArgs e)
    {
        if ((Session["status"] != "Valid"))
        {
            Response.Redirect("~\\LogIn.aspx", true);
            return;
        }

        if (!IsPostBack)
        {
            if ((Session["status"] == "Valid"))
            {
                if (Session["isRestrict"].Equals("YES"))
                {
                    this.TreeView1.Nodes.RemoveAt(0);
                }
                else
                {
                    //this.TreeView1.Nodes.RemoveAt();
                    if (Session["UserType"].Equals("AUDIT"))
                    {
                        this.TreeView1.Nodes.RemoveAt(0);
                        TreeView1.Nodes[0].ChildNodes.RemoveAt(0);
                    }
                    else 
                    {
                        TreeView1.Nodes[1].ChildNodes.RemoveAt(0);
                    }
                   
                }
            }
              
        }

        Response.Expires = 0;
        Response.Cache.SetNoStore();
        //}
        //if ((Session["status"] == "Valid"))
        //{
        //    if (!Session["UserName"].Equals(""))
        //    {
        //        lblUserName.Text = "Welcome : " + Session["UserName"].ToString();
        //    }
        //}
        //if (Session["InternalUser"].ToString() == "YES")
        //{
        //    //hplOtherlinks.Visible = false;
        //    hplCngPwd.Visible = true;
        //}
        //else
        //{
        //    Response.Redirect("~\\LogIn.aspx", true);
        //            return;
        //}

        //lblLastModi.Text = "Last modified on " + Session["LastRun"].ToString();
    }

    //protected void MasterButton_Click(object sender, EventArgs e)
    //{
    //     switch (((Control)sender).ID)
    //    {
    //        case "IncrementButton":
    //            this.Offset = this.Offset + 1;
    //            break;
    //        case "DecrementButton":
    //            this.Offset = this.Offset - 1;
    //            break;
    //    }
    //    ((UpdatePanel)ContentPlaceHolder1.FindControl("UpdatePanel2")).Update();
    //    //Calendar cal = ((Calendar)ContentPlaceHolder1.FindControl("Calendar1"));
    //    //DateTime newDateTime = DateTime.Today.Add(new TimeSpan(Offset, 0, 0, 0));
    //    //cal.SelectedDate = newDateTime; 

    //}
    //public Int32 Offset
    //{
    //    get
    //    { return (Int32)(ViewState["Offset"] ?? 0); }
    //    set
    //    { ViewState["Offset"] = value; }
    //}

    protected void lkbLogOut_Click(object sender, EventArgs e)
    {
        try
        {
            Session["status"] = "InValid";
            Session["UserID"] = "";
            Session["UserName"] = "";
            Session["branchCode"] = "";
            Session["dtlBranch"]= "";
            Session["password"] = "";
            Session["ischangepwd"] = "yes";
            Session["isRestrict"] = "yes";
            Session.Abandon();
            Response.Redirect("~\\login.aspx", false);
            //FormsAuthentication.RedirectToLoginPage();

        }
        catch (Exception)
        {
            
            throw;
        }
    }
}
