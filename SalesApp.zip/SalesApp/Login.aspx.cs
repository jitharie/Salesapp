﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text.RegularExpressions;

public partial class _Login : System.Web.UI.Page
{
    #region .. Variables ..

    DataSet dsUser;
    String Uid;
    String PwdEncript;
    #endregion
    //protected void Page_Load(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (!this.IsPostBack)
    //        {
          
    //            Session["status"] = "invalid";
    //            Session["UserRank"] = "100";
    //            Session["ischangepwd"] = "yes";
    //            txtUserName.Focus();

    //             Uid = Request.QueryString["uid"];
    //             Session["LoginId"] = Uid;
    //             PwdEncript = Request.QueryString["pwd"];

    //            if ((!String .IsNullOrEmpty(Uid))&& (!String .IsNullOrEmpty(PwdEncript)))
    //            {
    //                UserValidate(Uid, PwdEncript);          
    //            }
    //        }
    //    }
    //    catch (Exception)
    //    {           
    //        throw;
    //    }

    //}
    //private bool IsTextValidated(string strTextEntry)
    //{
    //    Regex objNotWholePattern = new Regex("[^0-9]");
    //    return !objNotWholePattern.IsMatch(strTextEntry);
    //}
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            if (this.IsPostBack)
            {
                Uid = txtUserName.Text.ToString().Replace("-", "").Trim();
                Session["LoginId"] = Uid;
                PwdEncript = commonfunctions.Encrypt(txtPassword.Text.ToString().Trim());
                UserValidate(Uid, PwdEncript);
            }
        }
        catch (Exception)
        {
            WebMsgBox.Show("Error occurred in authentication process.Please contact the system administrator for details!");
        }
    }

    private void UserValidate(String Uid, String PwdEncript)
    {
        try
        {
            GetData clsGetdata = new GetData();
            ////--------------------Get System Last update Date-------------------
            //DataSet dsLstModi = clsGetdata.getLstModi();
            //if (dsLstModi.Tables[0].Rows.Count > 0)
            //{
            //    Session["LastRun"] = dsLstModi.Tables[0].Rows[0]["LASTRUN"].ToString();
            //}

            //Authentication Process from data wareHouse
            DataSet dsUser = clsGetdata.getIntranetUser(Uid, PwdEncript);
            if (dsUser.Tables[0].Rows.Count > 0)
            {
                string Usertype = dsUser.Tables[0].Rows[0]["USERTYPE"].ToString();
                string UserBranch = dsUser.Tables[0].Rows[0]["BRANCH"].ToString();
                if (((Usertype == "USER") && (UserBranch != "HO01")) || (Usertype == "ACCOUNTANT") || (Usertype == "AUDIT"))
                {
                        Session["EMPID"] = dsUser.Tables[0].Rows[0]["EMPID"].ToString().Trim();//"000553";
                        Session["UserName"] = dsUser.Tables[0].Rows[0]["NAME"].ToString();
                        Session["branchCode"] = UserBranch;
                        Session["UserType"] = Usertype;
                        Session["status"] = "Valid";
                    if (Usertype == "AUDIT")
                        Session["isRestrict"] = "NO";
                    else
                        Session["isRestrict"] = "YES";

                        //InsUserLog();
                        Response.Redirect("~/Default.aspx", false);
                        return;                   
                }
                
                else
                {
                   DataSet dsSuperUser = clsGetdata.getSuperUser(Uid);
                   if (dsSuperUser.Tables[0].Rows.Count > 0)
                   {
                       Session["EMPID"] = dsUser.Tables[0].Rows[0]["EMPID"].ToString().Trim();//"000553";
                       Session["UserName"] = dsUser.Tables[0].Rows[0]["NAME"].ToString();
                       Session["branchCode"] = UserBranch;
                       Session["UserType"] = "Super";
                       Session["status"] = "Valid";
                       Session["isRestrict"] = "NO";

                       //InsUserLog();
                       Response.Redirect("~/Default.aspx", false);
                       return;
                   }
                   else
                   {
                       lblMsg.Text = "You do not have permission!";
                       return;
                   }
                }
            }
            else
            {
                lblMsg.Text = "Login details are invalid!";
                return;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    //private void internalPasswordChk()
    //{
    //    try
    //    {
    //        //if (IsTextValidated(txtUserName.Text.ToString().Trim()))
    //        //{
    //        //-----------first time login -----------
    //        // if (txtUserName.Text.ToString().ToLower ().Trim().Equals ("system") && txtPassword.Text.ToString().Trim().Equals("cey"))
    //        GetData clsGetData = new GetData();
    //        if (Uid == txtPassword.Text.ToString().ToLower().Trim())
    //        {
    //            DataSet dsNewUser = clsGetData.isPasswordBlank(Uid);
    //            if (dsNewUser.Tables[0].Rows.Count > 0)
    //            {
    //                Session["UserID"] = dsNewUser.Tables[0].Rows[0]["USER_CODE"].ToString();
    //                Session["UserName"] = dsNewUser.Tables[0].Rows[0]["USER_NAME"].ToString();
    //                Session["branchCode"] = dsNewUser.Tables[0].Rows[0]["BRANCH_CODE"].ToString();
    //                if (Session["branchCode"].ToString().Equals("HO"))
    //                {
    //                    Session["UserType"] = "SUPER";
    //                    Session["UserRank"] = "10"; 
    //                }
    //                else
    //                {
    //                    Session["UserType"] = "MBD";
    //                    Session["UserRank"] = "20"; 
    //                }
    //                //Session["password"] = "";

    //                Session["status"] = "Valid";
    //                Session["ischangepwd"] = "yes";
    //                InsUserLog();
    //                Session["InternalUser"] = "YES";
    //                Response.Redirect("~\\ChangePWD.aspx", false);
    //            }
    //            else
    //            {
    //                lblMsg.Text = "Login details are invalid!";
    //                LinkButton1.Text = "Login Info.";
    //                //Literal1.Text = "Login details are invalid!";
    //                return;
    //            }
    //        }
    //        else
    //        {
    //            dsUser = clsGetData.getUser(Uid, commonfunctions.EncryptRegSetting(txtPassword.Text.ToString().Trim()));
    //            if (dsUser.Tables[0].Rows.Count > 0)
    //            {
    //                Session["UserID"] = dsUser.Tables[0].Rows[0]["USER_CODE"].ToString();
    //                Session["UserName"] = dsUser.Tables[0].Rows[0]["USER_NAME"].ToString();
    //                Session["branchCode"] = dsUser.Tables[0].Rows[0]["BRANCH_CODE"].ToString();
    //                if (Session["branchCode"].ToString().Equals("HO"))
    //                {
    //                    Session["isRestrict"] = "NO";
    //                    Session["UserType"] = "SUPER";
    //                    Session["UserRank"] = "10"; 
    //                }
    //                else
    //                {
    //                    Session["UserType"] = "MBD";
    //                    Session["UserRank"] = "20"; 
    //                }
    //                Session["password"] = commonfunctions.EncryptRegSetting(txtPassword.Text.ToString());

    //                Session["status"] = "Valid";
    //                Session["ischangepwd"] = "no";
    //                Session["InternalUser"] = "YES";
    //                //FormsAuthentication.RedirectFromLoginPage("", true);
    //                InsUserLog();
    //                Response.Redirect("~\\Branch.aspx", false);

    //            }
    //            else
    //            {
    //                lblMsg.Text = "Login details are invalid!";
    //                LinkButton1.Text = "Login Info.";
    //                //Literal1.Text = "Login details are invalid!";
    //                return;
    //            }
    //        }    
    //    }
    //    catch (Exception)
    //    {           
    //        throw;
    //    }
    //}
    //private void InsUserLog()
    //{
    //    try
    //    {
    //        System.Net.IPHostEntry host = new System.Net.IPHostEntry();
    //        host = System.Net.Dns.GetHostByAddress(Request.ServerVariables["REMOTE_HOST"]);
    //        String clientDtl = host.HostName + "-" + host.AddressList[0].ToString();
           

    //        //String clientDtl = Request.ServerVariables["remote_addr"].ToString();
    //        GetData clsGetData = new GetData();
    //        clsGetData.Ins_USER_LOG(clientDtl,Uid);//Session["UserID"].ToString()
    //    }
    //    catch (Exception)
    //    {            

    //    }
    //}

}
