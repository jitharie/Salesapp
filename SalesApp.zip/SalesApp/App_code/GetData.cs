﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.ApplicationBlocks.Data;


/// <summary>
/// Summary description for GetData
/// </summary>
public class GetData
{
    string strConnString = ConfigurationManager.ConnectionStrings["SalesAppConnStr"].ConnectionString;
	public GetData()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataSet getIntranetUser(String USER_ID, String PASSWORDED)//[192.168.100.42].DWH.USERTYPE IN ('ACCOUNTANT','HOB','MBD','UNITHEAD','AUDIT') AND
    {
        String strQuery = @"SELECT PASSWORD_NEW_SYSTEM.EMPID,PASSWORD_NEW_SYSTEM.PID," + Environment.NewLine +
                            @"PASSWORD_NEW_SYSTEM.NAME, PASSWORD_NEW_SYSTEM.BRANCH, " + Environment.NewLine +
                            @"PASSWORD_NEW_SYSTEM.USERTYPE" + Environment.NewLine +
                            @"FROM  DBO.PASSWORD_NEW_SYSTEM " + Environment.NewLine +
                            @"WHERE ((PASSWORD_NEW_SYSTEM.EMPID = '" + USER_ID + "') OR (PASSWORD_NEW_SYSTEM.PID = '" + USER_ID + "'))" + Environment.NewLine +
                            @"AND (PASSWORD_NEW_SYSTEM.PASSWORDED = '" + PASSWORDED + "') AND (PASSWORD_NEW_SYSTEM.STATUS = 'ACTIVE')";

         string strConnString = ConfigurationManager.ConnectionStrings["dwhConnStr"].ConnectionString;
         return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
    }

    public DataSet getUserBranch(string Uid)
    {
        String strQuery = @"SELECT DISTINCT BRANCH FROM WEB_USER_GROUP WHERE EMPID ='" + Uid + "' ORDER BY BRANCH";

        string strConnString = ConfigurationManager.ConnectionStrings["dwhConnStr"].ConnectionString;
        return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
    }

    public DataSet getSuperUser(string Uid)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[1];

        param[0] = new SqlParameter("@Uid", SqlDbType.VarChar);
        param[0].Value = Uid.Trim();

        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetSuperUser", param);
    }
    

    public DataSet getAllBranch()
    {             
        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetAllBranch");
    }

   
    public DataSet getSoByBranch(string branchCode)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[1];

        param[0] = new SqlParameter("@BRANCH", SqlDbType.VarChar);
        param[0].Value = branchCode.Trim();
      
        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetSoByBranch", param);
    }

    public DataSet getAllSoByBranchStr(string BranchStr)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[1];

        param[0] = new SqlParameter("@BRANCH_STRING", SqlDbType.VarChar);
        param[0].Value = BranchStr.Trim();
    
        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_getAllSoByBranchStr", param);

    }

    public DataSet getAllSo()
    {  
        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetAllSo");
        
    }

    public DataSet getBank()
    {   
        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_getBanks");
    }
}
