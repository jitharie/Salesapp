﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.Common;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.IO;
using System.Text;
/// <summary>
/// Summary description for commonfunctions
/// </summary>
public static class commonfunctions
{
    //public static String UserID = "";
    //public static String password = "";
    //public static String UserName = "";
    //public static String branchCode = "";

    static commonfunctions()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static string EncryptRegSetting(string strValue)
    {
        string strResult = "";
        try
        {
            double intCount = 0.0;
            string strEncrypt = "";
            string strReverse = "";
            bool blnExit = false;
            strValue = strValue.Trim();
            for (intCount = 1.0; intCount <= Strings.Len(strValue); intCount++)
            {
                strEncrypt = strEncrypt + Strings.Format(Strings.Asc(Strings.Mid(strValue, (int)Math.Round(Math.Round(intCount)), 1)), "000");
            }
            intCount = Strings.Len(strEncrypt) - 2;
            while (!blnExit)
            {
                strReverse = strReverse + Strings.Mid(strEncrypt, (int)Math.Round(Math.Round(intCount)), 3);
                intCount -= 3.0;
                if (intCount < 1.0)
                {
                    blnExit = true;
                }
            }
            strResult = Strings.Trim(strReverse);
        }
        catch (Exception exception1)
        {

            throw exception1;
        }
        return strResult;

    }
    public static object DecryptRegSetting(string strValue)
    {
        object objResult = null;
        try
        {
            string strReverse = "";
            bool blnExit = false;
            double intCount = Strings.Len(strValue) - 2;
            if (Strings.Len(strValue) >= 1)
            {
                while (!blnExit)
                {
                    strReverse = strReverse + Strings.Mid(strValue, (int)Math.Round(Math.Round(intCount)), 3);
                    intCount -= 3.0;
                    if (intCount < 1.0)
                    {
                        blnExit = true;
                    }
                }
                strReverse = Strings.Trim(strReverse);
                string strEncrypt = "";
                blnExit = false;
                intCount = 1.0;
                while (!blnExit)
                {
                    strEncrypt = strEncrypt + Conversions.ToString(Strings.Chr(Conversions.ToInteger(Strings.Mid(strReverse, (int)Math.Round(Math.Round(intCount)), 3))));
                    intCount += 3.0;
                    if (intCount > Strings.Len(strReverse))
                    {
                        blnExit = true;
                    }
                }
                return strEncrypt;
            }
            objResult = "";
        }
        catch (Exception exception1)
        {

            throw exception1;

        }
        return objResult;
    }
    public static string Encrypt(string strText)
    {
        string strEncrypt = "&%#@?,:*";
        string str;
        byte[] rgbKey = new byte[20];
        byte[] rgbIV = new byte[] { 0x12, 0x34, 0x56, 120, 0x91, 0xab, 0xcd, 0xef };
        try
        {
            rgbKey = Encoding.UTF8.GetBytes(strEncrypt.Substring(0, 8));
            DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
            byte[] bytes = Encoding.UTF8.GetBytes(strText);
            MemoryStream stream = new MemoryStream();
            CryptoStream stream2 = new CryptoStream(stream, provider.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
            stream2.Write(bytes, 0, bytes.Length);
            stream2.FlushFinalBlock();
            str = Convert.ToBase64String(stream.ToArray());
        }
        catch (Exception exception)
        {
            throw exception;
        }
        return str;
    }
   
}
