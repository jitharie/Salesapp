﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
/// <summary>
/// Summary description for clsUsers
/// </summary>
public class clsUsers
{

    string strConnString = ConfigurationManager.ConnectionStrings["SalesAppConnStr"].ConnectionString;
	
	private String  mSOCode  ;
	private String  mSalt  ;
	private String  mPassword  ;
	private String  mIMEI  ;
    private String mTEL_1;
    private String mTEL_2;
	private String  mStatus  ;
    private String mLogged;
    private String mCollection_User;
	private String  mCreate_User  ;
	private DateTime  mCreate_date  ;
	private DateTime  mLast_Sync_date  ;
	private String  mLast_Modified_user  ;
	private DateTime  mLast_Modified_date  ;
	private DateTime  mLastUpdated  ;
    private String  mSim_IP  ;
    private String  mDevice_Own  ;
    private String  mDevice_Type  ;
    private String  mDevice_Brand  ;
    private String  mIssue_Type  ;
    private String  mPrinter_Serial_No  ;
    private String  mMPOS_Device_Issued  ;
    private String  mMPOS_User_Id  ;

    public String Sim_IP
    {
        get
        {
            return mSim_IP;
        }
        set
        {
            mSim_IP = value;

        }
    }

    public String Device_Own
    {
        get
        {
            return mDevice_Own;
        }
        set
        {
            mDevice_Own = value;

        }
    }

    public String Device_Type
    {
        get
        {
            return mDevice_Type;
        }
        set
        {
            mDevice_Type = value;

        }
    }

    public String Device_Brand
    {
        get
        {
            return mDevice_Brand;
        }
        set
        {
            mDevice_Brand = value;

        }
    }

    public String Issue_Type
    {
        get
        {
            return mIssue_Type;
        }
        set
        {
            mIssue_Type = value;

        }
    }

    public String MPOS_User_Id
    {
        get
        {
            return mMPOS_User_Id;
        }
        set
        {
            mMPOS_User_Id = value;

        }
    }

    public String MPOS_Device_Issued
    {
        get
        {
            return mMPOS_Device_Issued;
        }
        set
        {
            mMPOS_Device_Issued = value;

        }
    }

    public String Printer_Serial_No
    {
        get
        {
            return mPrinter_Serial_No;
        }
        set
        {
            mPrinter_Serial_No = value;

        }
    }

   
	
		public String  SOCode  {
			get
			{
				return mSOCode;
			}
			set
			{
				mSOCode = value;
					
		    }	
			}
	
	
	
		public String Salt 
		{
			get
			{
				return mSalt;
			}
		
			set 
			{
				mSalt = value;
				}
		}
			
	
	
	
		public String Password 
		{
			get
			{
				return mPassword;
			}
		
			set 
			{
				mPassword = value;
				}
		}
			
	
	
	
		public String IMEI 
		{
			get
			{
				return mIMEI;
			}
		
			set 
			{
				mIMEI = value;
				}
		}
        public String TEL_1
        {
            get
            {
                return mTEL_1;
            }

            set
            {
                mTEL_1 = value;
            }
        }

        public String TEL_2
        {
            get
            {
                return mTEL_2;
            }

            set
            {
                mTEL_2 = value;
            }
        }	
	
	
		public String Status 
		{
			get
			{
				return mStatus;
			}
		
			set 
			{
				mStatus = value;
				}
		}




        public String Logged 
		{
			get
			{
				return mLogged;
			}
		
			set 
			{
				mLogged = value;
				}
		}

        public String Collection_User
        {
            get
            {
                return mCollection_User;
            }

            set
            {
                mCollection_User = value;
            }
        }
	
	
		public String Create_User 
		{
			get
			{
				return mCreate_User;
			}
		
			set 
			{
				mCreate_User = value;
				}
		}
			
	
	
	
		public DateTime Create_date 
		{
			get
			{
				return mCreate_date;
			}
		
			set 
			{
				mCreate_date = value;
				}
		}
			
	
	
	
		public DateTime Last_Sync_date 
		{
			get
			{
				return mLast_Sync_date;
			}
		
			set 
			{
				mLast_Sync_date = value;
				}
		}
			
	
	
	
		public String Last_Modified_user 
		{
			get
			{
				return mLast_Modified_user;
			}
		
			set 
			{
				mLast_Modified_user = value;
				}
		}
			
	
	
	
		public DateTime Last_Modified_date 
		{
			get
			{
				return mLast_Modified_date;
			}
		
			set 
			{
				mLast_Modified_date = value;
				}
		}
			
	
	
	
		public DateTime LastUpdated 
		{
			get
			{
				return mLastUpdated;
			}
		
			set 
			{
				mLastUpdated = value;
				}
		}


        public DataSet GetAgents(string SOCode)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[1];

            param[0] = new SqlParameter("@SOCode", SqlDbType.Int);
            param[0].Value = SOCode.Trim();

            return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetAgents",param);
            
        }

        public DataSet GetSalesOneUser(string SOCode)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[1];

            param[0] = new SqlParameter("@SOCode", SqlDbType.Int);
            param[0].Value = SOCode.Trim();

            return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetSalesOneUser", param);
        }

        public DataSet GetSalesAppUser(string SOCode)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[1];

            param[0] = new SqlParameter("@SOCode", SqlDbType.Int);
            param[0].Value = SOCode.Trim();

            return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetSalesAppUser", param);
        }

        public int InsUsers(clsUsers objUser)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[13];

            param[0] = new SqlParameter("@SOCode", SqlDbType.VarChar);
            param[0].Value = objUser.SOCode.ToString();

            param[1] = new SqlParameter("@IMEI", SqlDbType.VarChar);
            param[1].Value = objUser.IMEI.ToString();

            param[2] = new SqlParameter("@Create_User", SqlDbType.VarChar);
            param[2].Value = objUser.Create_User.ToString();

            param[3] = new SqlParameter("@TEL_1", SqlDbType.VarChar);
            param[3].Value = objUser.TEL_1.ToString();

            param[4] = new SqlParameter("@TEL_2", SqlDbType.VarChar);
            param[4].Value = objUser.TEL_2.ToString();

            param[5] = new SqlParameter("Collection_User", SqlDbType.VarChar);
            param[5].Value = objUser.Collection_User.ToString();

            param[6] = new SqlParameter("Sim_IP", SqlDbType.VarChar);
            param[6].Value = objUser.Sim_IP.ToString();
            
            param[7] = new SqlParameter("Printer_Serial_No", SqlDbType.VarChar);
            param[7].Value = objUser.Printer_Serial_No.ToString();

             param[8] = new SqlParameter("Device_Type", SqlDbType.VarChar);
            param[8].Value = objUser.Device_Type.ToString();

             param[9] = new SqlParameter("Device_Brand", SqlDbType.VarChar);
            param[9].Value = objUser.Device_Brand.ToString();

             param[10] = new SqlParameter("Device_Own", SqlDbType.VarChar);
            param[10].Value = objUser.Device_Own.ToString();

            param[11] = new SqlParameter("MPOS_Device_Issued", SqlDbType.VarChar);
            param[11].Value = objUser.MPOS_Device_Issued.ToString();

            param[12] = new SqlParameter("MPOS_User_Id", SqlDbType.VarChar);
            param[12].Value = objUser.MPOS_User_Id.ToString();

            

           return SqlHelper.ExecuteNonQuery(strConnString, CommandType.StoredProcedure, "usp_InsUsers", param);
        }

        public DataSet GetUserDtl(string SOCode)
        {
           SqlParameter[] param = null;
            param = new SqlParameter[1];

            param[0] = new SqlParameter("@SOCode", SqlDbType.Int);
            param[0].Value = SOCode.Trim();

            return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetUserDtl", param);
        }
        public DataSet GetSearchUser(string Type,string strParam)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[2];

            param[0] = new SqlParameter("@Type", SqlDbType.VarChar);
            param[0].Value = Type.Trim();

            param[1] = new SqlParameter("@strParam", SqlDbType.VarChar);
            param[1].Value = strParam.Trim();
            return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetUserSearch", param);
        }
        public int UpdUsers(clsUsers objUser)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[16];

            param[0] = new SqlParameter("@SOCode", SqlDbType.VarChar);
            param[0].Value = objUser.SOCode.ToString();

            param[1] = new SqlParameter("@IMEI", SqlDbType.VarChar);
            param[1].Value = objUser.IMEI.ToString();

            param[2] = new SqlParameter("@STATUS", SqlDbType.VarChar);
            param[2].Value = objUser.Status.ToString();

            param[3] = new SqlParameter("@LOGGED", SqlDbType.VarChar);
            param[3].Value = objUser.Logged.ToString();

            param[4] = new SqlParameter("Collection_User", SqlDbType.VarChar);
            param[4].Value = objUser.Collection_User.ToString();

            param[5] = new SqlParameter("@PASSWORD", SqlDbType.VarChar);
            param[5].Value = objUser.Password.ToString();

            param[6] = new SqlParameter("@LAST_MODIFIED_USER", SqlDbType.VarChar);
            param[6].Value = objUser.Last_Modified_user.ToString();

            param[7] = new SqlParameter("@TEL_1", SqlDbType.VarChar);
            param[7].Value = objUser.TEL_1.ToString();

            param[8] = new SqlParameter("@TEL_2", SqlDbType.VarChar);
            param[8].Value = objUser.TEL_2.ToString();


            param[9] = new SqlParameter("Sim_IP", SqlDbType.VarChar);
            param[9].Value = objUser.Sim_IP.ToString();

            param[10] = new SqlParameter("Printer_Serial_No", SqlDbType.VarChar);
            param[10].Value = objUser.Printer_Serial_No.ToString();

            param[11] = new SqlParameter("Device_Type", SqlDbType.VarChar);
            param[11].Value = objUser.Device_Type.ToString();

            param[12] = new SqlParameter("Device_Brand", SqlDbType.VarChar);
            param[12].Value = objUser.Device_Brand.ToString();

            param[13] = new SqlParameter("Device_Own", SqlDbType.VarChar);
            param[13].Value = objUser.Device_Own.ToString();

            param[14] = new SqlParameter("MPOS_Device_Issued", SqlDbType.VarChar);
            param[14].Value = objUser.MPOS_Device_Issued.ToString();

            param[15] = new SqlParameter("MPOS_User_Id", SqlDbType.VarChar);
            param[15].Value = objUser.MPOS_User_Id.ToString();

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.StoredProcedure, "usp_UpdUsers", param);
        }
}

