﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
/// <summary>
/// Summary description for clsCollection
/// </summary>
public class clsCollection
{
    string strConnString = ConfigurationManager.ConnectionStrings["SalesAppConnStr"].ConnectionString;
	
	public clsCollection()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    private String mSOCode;
    private String mCSSNo;
    private String mReceiptSeqNo;
    private String mTxnSt;
    private String mCollectionType;
    private DateTime mReceiptDate;
    private String mContractNo;
    private Double mLoanInt;
    private Int64 mSalutation;
    private String mCustomerName;
    private String mCustomerIDNo;
    private Int64 mCustomerIDType;
    private String mAddress1;
    private String mAddress2;
    private String mAddress3;
    private String mPostalCode;
    private DateTime mDOB;
    private Int64 mCivilStatus;
    private String mGender;
    private String mPaymentMethod;
    private Double mCollectionAmt;
    private DateTime mChequeDate;
    private String mChequeNo;
    private String mBankCode;
    private String mBranchCode;
    private String mCustomerId;
    private String mRemarks;
    private String mRemarksCashier;
    private String mVerifiedBy;
    private DateTime mVerifiedDate;
    private String mBankState;
    private DateTime mLastUpdated;
    private Boolean mPrintReceipt;
    private Boolean mPrintCSS;
    private String mRec_Status;
    private String mCollectionStatus;
    private String mSignature;
    private String mReason;
    private String mChangeLog;
    private String mDoneBy;
    private DateTime mCSSCreatedDate;
    private Boolean mIsCancelled;


    //

    public String SOCode
    {
        get
        {
            return mSOCode;
        }
        set
        {
            mSOCode = value;           
        }
    }



    public String CSSNo
    {
        get
        {
            return mCSSNo;
        }

        set
        {
            mCSSNo = value;
        }
    }



    public String ReceiptSeqNo
    {
        get
        {
            return mReceiptSeqNo;
        }
        set
        {
            mReceiptSeqNo = value;
           
        }
    }



    public String TxnSt
    {
        get
        {
            return mTxnSt;
        }

        set
        {
            mTxnSt = value;
        }
    }




    public String CollectionType
    {
        get
        {
            return mCollectionType;
        }

        set
        {
            mCollectionType = value;
        }
    }




    public DateTime ReceiptDate
    {
        get
        {
            return mReceiptDate;
        }

        set
        {
            mReceiptDate = value;
        }
    }




    public String ContractNo
    {
        get
        {
            return mContractNo;
        }

        set
        {
            mContractNo = value;
        }
    }




    public Double LoanInt
    {
        get
        {
            return mLoanInt;
        }

        set
        {
            mLoanInt = value;
        }
    }




    public Int64 Salutation
    {
        get
        {
            return mSalutation;
        }

        set
        {
            mSalutation = value;
        }
    }




    public String CustomerName
    {
        get
        {
            return mCustomerName;
        }

        set
        {
            mCustomerName = value;
        }
    }




    public String CustomerIDNo
    {
        get
        {
            return mCustomerIDNo;
        }

        set
        {
            mCustomerIDNo = value;
        }
    }




    public Int64 CustomerIDType
    {
        get
        {
            return mCustomerIDType;
        }

        set
        {
            mCustomerIDType = value;
        }
    }




    public String Address1
    {
        get
        {
            return mAddress1;
        }

        set
        {
            mAddress1 = value;
        }
    }




    public String Address2
    {
        get
        {
            return mAddress2;
        }

        set
        {
            mAddress2 = value;
        }
    }




    public String Address3
    {
        get
        {
            return mAddress3;
        }

        set
        {
            mAddress3 = value;
        }
    }




    public String PostalCode
    {
        get
        {
            return mPostalCode;
        }

        set
        {
            mPostalCode = value;
        }
    }




    public DateTime DOB
    {
        get
        {
            return mDOB;
        }

        set
        {
            mDOB = value;
        }
    }




    public Int64 CivilStatus
    {
        get
        {
            return mCivilStatus;
        }

        set
        {
            mCivilStatus = value;
        }
    }




    public String Gender
    {
        get
        {
            return mGender;
        }

        set
        {
            mGender = value;
        }
    }




    public String PaymentMethod
    {
        get
        {
            return mPaymentMethod;
        }

        set
        {
            mPaymentMethod = value;
        }
    }




    public Double CollectionAmt
    {
        get
        {
            return mCollectionAmt;
        }

        set
        {
            mCollectionAmt = value;
        }
    }




    public DateTime ChequeDate
    {
        get
        {
            return mChequeDate;
        }

        set
        {
            mChequeDate = value;
        }
    }




    public String ChequeNo
    {
        get
        {
            return mChequeNo;
        }

        set
        {
            mChequeNo = value;
        }
    }




    public String BankCode
    {
        get
        {
            return mBankCode;
        }

        set
        {
            mBankCode = value;
        }
    }




    public String BranchCode
    {
        get
        {
            return mBranchCode;
        }

        set
        {
            mBranchCode = value;
        }
    }




    public String CustomerId
    {
        get
        {
            return mCustomerId;
        }

        set
        {
            mCustomerId = value;
        }
    }




    public String Remarks
    {
        get
        {
            return mRemarks;
        }

        set
        {
            mRemarks = value;
        }
    }




    public String RemarksCashier
    {
        get
        {
            return mRemarksCashier;
        }

        set
        {
            mRemarksCashier = value;
        }
    }




    public String VerifiedBy
    {
        get
        {
            return mVerifiedBy;
        }

        set
        {
            mVerifiedBy = value;
        }
    }




    public DateTime VerifiedDate
    {
        get
        {
            return mVerifiedDate;
        }

        set
        {
            mVerifiedDate = value;
        }
    }




    public String BankState
    {
        get
        {
            return mBankState;
        }

        set
        {
            mBankState = value;
        }
    }




    public DateTime LastUpdated
    {
        get
        {
            return mLastUpdated;
        }

        set
        {
            mLastUpdated = value;
        }
    }




    public Boolean PrintReceipt
    {
        get
        {
            return mPrintReceipt;
        }

        set
        {
            mPrintReceipt = value;
        }
    }




    public Boolean PrintCSS
    {
        get
        {
            return mPrintCSS;
        }

        set
        {
            mPrintCSS = value;
        }
    }




    public String Rec_Status
    {
        get
        {
            return mRec_Status;
        }

        set
        {
            mRec_Status = value;
        }
    }




    public String CollectionStatus
    {
        get
        {
            return mCollectionStatus;
        }

        set
        {
            mCollectionStatus = value;
        }
    }




    public String Signature
    {
        get
        {
            return mSignature;
        }

        set
        {
            mSignature = value;
        }
    }




    public String Reason
    {
        get
        {
            return mReason;
        }

        set
        {
            mReason = value;
        }
    }




    public String ChangeLog
    {
        get
        {
            return mChangeLog;
        }

        set
        {
            mChangeLog = value;
        }
    }




    public String DoneBy
    {
        get
        {
            return mDoneBy;
        }

        set
        {
            mDoneBy = value;
        }
    }




    public DateTime CSSCreatedDate
    {
        get
        {
            return mCSSCreatedDate;
        }

        set
        {
            mCSSCreatedDate = value;
        }
    }




    public Boolean IsCancelled
    {
        get
        {
            return mIsCancelled;
        }

        set
        {
            mIsCancelled = value;
        }
    }



    public DataSet GetCollectionSummary(string BranchStr)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[1];

        param[0] = new SqlParameter("@BRANCH_STRING", SqlDbType.VarChar);
        param[0].Value = BranchStr.Trim();

        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetCollection", param);

    }



    public DataSet GetCollectionDtl(string PaymentMethod, string socode, string cssno)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[3];

        param[0] = new SqlParameter("@PAYMENTMETHOD", SqlDbType.VarChar);
        param[0].Value = PaymentMethod.Trim();

        param[1] = new SqlParameter("@SOCODE", SqlDbType.VarChar);
        param[1].Value = socode.Trim();

        param[2] = new SqlParameter("@CSSNO", SqlDbType.VarChar);
        param[2].Value = cssno.Trim();

        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetCollectionDtl", param);
    }

    public DataSet GetLastSyncDtl(string socode, string cssno)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[2];

        param[0] = new SqlParameter("@SOCODE", SqlDbType.VarChar);
        param[0].Value = socode.Trim();

        param[1] = new SqlParameter("@CSSNO", SqlDbType.VarChar);
        param[1].Value = cssno.Trim();

        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetLastSyncDtl", param);
    }
    public DataSet GetRctDtl(string socode, string rctNo)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[2];

        param[0] = new SqlParameter("@SOCode", SqlDbType.VarChar);
        param[0].Value = socode.Trim();

        param[1] = new SqlParameter("@ReceiptSeqNo", SqlDbType.VarChar);
        param[1].Value = rctNo.Trim();

        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetRctDtl", param);
    }
    public DataSet GetCollectionTot(string socode, string cssno)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[2];

        param[0] = new SqlParameter("@SOCODE", SqlDbType.VarChar);
        param[0].Value = socode.Trim();

        param[1] = new SqlParameter("@CSSNO", SqlDbType.VarChar);
        param[1].Value = cssno.Trim();

        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetCollectionTot", param);
    }

    public int UpdCollectionVerify(clsCollection objCollection)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[13];

        param[0] = new SqlParameter("@SOCode", SqlDbType.VarChar);
        param[0].Value = objCollection.SOCode.ToString();

        param[1] = new SqlParameter("@ReceiptSeqNo", SqlDbType.VarChar);
        param[1].Value = objCollection.ReceiptSeqNo.ToString();

        param[2] = new SqlParameter("@CollectionType", SqlDbType.VarChar);
        param[2].Value = objCollection.CollectionType.ToString();

        param[3] = new SqlParameter("@ContractNo", SqlDbType.VarChar);
        param[3].Value = objCollection.ContractNo.ToString();

        param[4] = new SqlParameter("@LoanInt", SqlDbType.Float);
        param[4].Value = objCollection.LoanInt;

        param[5] = new SqlParameter("@PaymentMethod", SqlDbType.VarChar);
        param[5].Value = objCollection.PaymentMethod;

        param[6] = new SqlParameter("@ChequeNo", SqlDbType.VarChar);
        param[6].Value = objCollection.ChequeNo;

        param[7] = new SqlParameter("@BankCode", SqlDbType.VarChar);
        param[7].Value = objCollection.BankCode;

        param[8] = new SqlParameter("@BranchCode", SqlDbType.VarChar);
        param[8].Value = objCollection.BranchCode;

        param[9] = new SqlParameter("@VerifiedBy", SqlDbType.VarChar);
        param[9].Value = objCollection.VerifiedBy.ToString();

        param[10] = new SqlParameter("@BankState", SqlDbType.VarChar);
        param[10].Value = objCollection.BankState.ToString();

        param[11] = new SqlParameter("@Remarks", SqlDbType.VarChar);
        param[11].Value = objCollection.Remarks.ToString();

        param[12] = new SqlParameter("@TxnSt", SqlDbType.VarChar);
        param[12].Value = objCollection.TxnSt.ToString();

        return SqlHelper.ExecuteNonQuery(strConnString, CommandType.StoredProcedure, "usp_UpdCollectionVerify", param);
    }
    public int UpdCollectionCancelled(clsCollection objCollection)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[3];

        param[0] = new SqlParameter("@SOCode", SqlDbType.VarChar);
        param[0].Value = objCollection.SOCode.ToString();

        param[1] = new SqlParameter("@ReceiptSeqNo", SqlDbType.VarChar);
        param[1].Value = objCollection.ReceiptSeqNo.ToString();

        //param[2] = new SqlParameter("@CollectionType", SqlDbType.VarChar);
        //param[2].Value = objCollection.CollectionType.ToString();

        //param[3] = new SqlParameter("@ContractNo", SqlDbType.VarChar);
        //param[3].Value = objCollection.ContractNo.ToString();

        //param[4] = new SqlParameter("@LoanInt", SqlDbType.Float);
        //param[4].Value = objCollection.LoanInt;

        param[2] = new SqlParameter("@VerifiedBy", SqlDbType.VarChar);
        param[2].Value = objCollection.VerifiedBy.ToString();

        //param[6] = new SqlParameter("@BankState", SqlDbType.VarChar);
        //param[6].Value = objCollection.BankState.ToString();

        return SqlHelper.ExecuteNonQuery(strConnString, CommandType.StoredProcedure, "usp_UpdCollectionCancelled", param);
    }

    public DataSet GetCollectionInquiry(string branchCode, string SoCode,string CollectionStatus,string CssNo,string BranchCodeStr)
    {

        String strQuery = @"SELECT CSSNO,AGENTS.BRANCH,'" + CollectionStatus + "' as [STATUS],[COLLECTION].SOCODE,CAST(CONVERT(VARCHAR, CSSCREATEDDATE, 111) AS " +
                   @"DATETIME) AS LAST_SYNC_DATE," + Environment.NewLine +
                   @"SUM(COLLECTIONAMT) AS COLLECTION_AMT FROM  [COLLECTION] INNER JOIN AGENTS ON " +
                   @"[COLLECTION].SOCODE=AGENTS.SOCODE" + Environment.NewLine +
                   @"WHERE 1=1 ";

                    //----------------Branch Filtering-----------------------------
                    if (branchCode != "ALL")
                    {
                        strQuery += " AND AGENTS.BRANCH='" + branchCode + "'";
                    }
                    else
                    {
                        if (BranchCodeStr != "")
                        {
                            strQuery += " AND AGENTS.BRANCH in (" + BranchCodeStr + ")";
                        }
                        
                    }
                    //----------------Status Filtering-----------------------------
                    if (CollectionStatus == "Syncronized")
                    {
                        strQuery += @" AND COLLECTIONSTATUS='SUBMITTED' ";
                    }
                    else 
                    {
                        strQuery += @" AND COLLECTIONSTATUS!='SUBMITTED' ";
                    }
                    //----------------So Filtering-----------------------------
                   if (SoCode!="ALL")
                    {
                        strQuery += " AND [COLLECTION].SOCODE='" + SoCode + "'";
                    }
                   //----------------Css Filtering-----------------------------
                   if (CssNo != "")
                   {
                       strQuery += " AND [COLLECTION].CSSNO='" + CssNo + "'";
                   }

                   strQuery += @" GROUP BY CSSNO,AGENTS.BRANCH,[COLLECTION].SOCODE,CAST(CONVERT(VARCHAR, CSSCREATEDDATE, 111) AS DATETIME)" + Environment.NewLine +
                   @"ORDER BY AGENTS.BRANCH,[COLLECTION].SOCODE";

        return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);

    }

    public DataSet GetCollectionInquiryDtl(string SoCode,string CssNo)
    {
        SqlParameter[] param = null;
        param = new SqlParameter[2];

        param[0] = new SqlParameter("@SOCODE", SqlDbType.VarChar);
        param[0].Value = SoCode.Trim();

        param[1] = new SqlParameter("@CSSNO", SqlDbType.VarChar);
        param[1].Value = CssNo.Trim();

        return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_GetCollectionInquiry", param);
    }


    public DataTable GetCollectionVerifyReport(string Type,string branch, string frmDate, string toDate)
    {
        String strQuery = @"SELECT Collection.SOCode,CollectionType,ReceiptDate,ContractNo=CASE WHEN " +
                        @"ContractNo='' THEN CustomerId" + Environment.NewLine +
                        @"ELSE ContractNo END,PaymentMethod,CollectionAmt,VerifiedBy,VerifiedDate," + Environment.NewLine +
                        @"CONVERT(DATETIME,'" + frmDate + "') AS fromDate,CONVERT(DATETIME,'" + toDate + "') AS toDate," + Environment.NewLine +
                        @"Agents.Branch AS [BranchName],ReceiptSeqNo" + Environment.NewLine +
                        @"FROM dbo.Collection  INNER JOIN dbo.Agents" + Environment.NewLine +
                        @"ON dbo.Collection.SOCode = dbo.Agents.SOCode" + Environment.NewLine +
                        @"WHERE CollectionStatus='" + Type + "'" + Environment.NewLine +
                        @"AND cast(convert(varchar, Collection.VerifiedDate, 111) as datetime) BETWEEN '" + frmDate + "' AND " +
                        @"'" + toDate + "'" + Environment.NewLine +
                        @"AND (Agents.Branch in (" + branch + "))";

        return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery).Tables[0];
    }
}
