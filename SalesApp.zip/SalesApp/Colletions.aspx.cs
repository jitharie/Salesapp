﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Colletions : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            if (Session["isRestrict"].Equals("NO"))
            {
                Response.Redirect("~\\LogIn.aspx", true);
                return;
            }
            if (!this.IsPostBack)
            {
                loadBranchCode();
                loadData(-1);
            }
        }
        catch (Exception)
        {           
            throw;
        }
    }

    private void loadBranchCode()
    {
        try
        {
            string EmpID=Session["EMPID"].ToString();           
            GetData clsGetdata = new GetData();
            DataSet dsBranch = null;

            dsBranch = clsGetdata.getUserBranch(EmpID);
            ddlBranch.DataSource = dsBranch.Tables[0];
            ddlBranch.DataTextField = "BRANCH";
            ddlBranch.DataValueField = "BRANCH";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, "ALL");

        }
        catch (Exception)
        {           
            throw;
        }
    }
    protected void LinkButtonUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btndetails = sender as LinkButton;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            LinkButton l = new LinkButton();
            l = (LinkButton)gvrow.FindControl("linkButtonUpdate");

            string info = l.CommandArgument;
            string[] arg = new string[2];
            char[] splitter = { ';' };
            arg = info.Split(splitter);
            string socode = arg[0];
            string cssno = arg[1];
            Session["socode"] = socode;
            Session["cssno"] = cssno;

            Response.Redirect("~/ColletionsVerify.aspx",true);
          
        }
        catch (Exception)
        {

            throw;
        }


    }
    protected void dgvUserDtl_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
             loadData(e.NewPageIndex);
        }
        catch (Exception)
        {
            
            throw;
        }
    }
    private void loadData(int pageIndex)
    {
        try
        {
             lblMessage.Text ="";
            string EmpID = Session["EMPID"].ToString();   
 
            clsCollection objclsCollection = new clsCollection();
            DataSet dsCollection = new DataSet();
            string brCode = GetBranchString();
            dsCollection = objclsCollection.GetCollectionSummary(brCode);


            if (dsCollection.Tables.Count > 0)
            {
                dgvUserDtl.DataSource = dsCollection.Tables[0];
                dgvUserDtl.PageIndex = pageIndex > 0 ? pageIndex : 0;
                dgvUserDtl.DataBind();

                if (dsCollection.Tables[0].Rows.Count == 0)
                {
                    lblMessage.Text = "Records not found!";
                }
            }
         
        }
        catch (Exception)
        {           
            throw;
        }
    }

    private string GetBranchString()
    {
        try
        {       string BranchStr = "";

            if (ddlBranch.SelectedValue.ToString() == "ALL")
            {               
                for (int i = 1; i < ddlBranch.Items.Count; i++)
                {
                    if (i==ddlBranch.Items.Count-1)
                        BranchStr+= "'"+ddlBranch.Items[i].Value.ToString()+"'";
                    else
                        BranchStr += "'" + ddlBranch.Items[i].Value.ToString() + "',"; ;
                }
            }
            else
            {
                BranchStr = "'" + ddlBranch.SelectedValue.ToString() + "'";
            }
            return BranchStr;
        }
        catch (Exception)
        {           
            throw;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            loadData(-1);
        }
        catch (Exception)
        {          
            throw;
        }
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
             loadData(-1);
        }
        catch (Exception)
        {
            
            throw;
        }
    }
}
