﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class UserEdit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["isRestrict"].Equals("YES"))
            {
                Response.Redirect("~\\LogIn.aspx", true);
                return;
            }
            //Session["EMPID"] = "SYSTEM";
            if (!this.IsPostBack)
            {
                string strSoCode=Session["SOCODE"].ToString ();
                lblSoCode.Text = strSoCode;
                fillAgent(strSoCode);
                fillUserDtl(strSoCode);
            }

        }
        catch (Exception)
        {
            
            throw;
        }
    }
    private void fillAgent(string SoCode)
    {
        if (!string.IsNullOrEmpty(SoCode))
        {
            
                clsUsers objUser = new clsUsers();
                DataSet dsAgents = new DataSet();
                dsAgents = objUser.GetAgents(SoCode);
                if (dsAgents.Tables[0].Rows.Count > 0)
                {
                    string Name = dsAgents.Tables[0].Rows[0]["NAME"].ToString();
                    string Branch = dsAgents.Tables[0].Rows[0]["BRANCH"].ToString();
                    string Socat = dsAgents.Tables[0].Rows[0]["SOTYPE"].ToString();
                    lblName.Text = Name.Trim() + "(" + Socat + ")" + Branch.PadLeft(100);
                }
                else
                {
                    lblName.Text = "";
                    //lblBranch.Text = "";
                    //lblSotype.Text = "";
                    lblMessage.Text = "Can not find agent code!";

                }
       
        }
    }

    private void fillUserDtl(string SoCode)
    {
        try
        {
            clsUsers objUser = new clsUsers();
            DataSet dsUser = new DataSet();
            dsUser = objUser.GetUserDtl(SoCode);
            if (dsUser.Tables[0].Rows.Count > 0)
            {
                txtImei.Text = dsUser.Tables[0].Rows[0]["IMEI"].ToString().Trim();
                txtTel1.Text = dsUser.Tables[0].Rows[0]["TEL_1"].ToString().Trim();
                txtTel2.Text = dsUser.Tables[0].Rows[0]["TEL_2"].ToString().Trim();
                ddlStatus.SelectedValue = dsUser.Tables[0].Rows[0]["STATUS"].ToString().Trim();
                txtDeviceBrand.Text = dsUser.Tables[0].Rows[0]["Device_Brand"].ToString().Trim();
                txtPrinterSerial.Text = dsUser.Tables[0].Rows[0]["Printer_Serial_No"].ToString().Trim();
                txtMposUserId.Text = dsUser.Tables[0].Rows[0]["MPOS_User_Id"].ToString().Trim();
                txtSimIp.Text = dsUser.Tables[0].Rows[0]["Sim_IP"].ToString().Trim();

                if (dsUser.Tables[0].Rows[0]["COLLECTION_USER"].ToString() == "True")
                {
                    ddlColletionUser.SelectedValue = "1";
                }
                else
                {
                    ddlColletionUser.SelectedValue = "0";
                }


                ddlDeviceOwnership.SelectedValue = dsUser.Tables[0].Rows[0]["Device_Own"].ToString().Trim();
                ddlDeviceType.SelectedValue = dsUser.Tables[0].Rows[0]["Device_Type"].ToString().Trim();
                ddlMposUser.SelectedValue = dsUser.Tables[0].Rows[0]["MPOS_Device_Issued"].ToString().Trim();
            }        
        }
        catch (Exception)
        {
            
            throw;
        }
               

    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        try
        {
            //---------Edit Process------------
            string strSoCode = Session["SOCODE"].ToString();
            clsUsers objUser = new clsUsers();

            objUser.SOCode = strSoCode.PadLeft(8, '0');
            objUser.IMEI = txtImei.Text.ToString();
            objUser.TEL_1 = txtTel1.Text.ToString();
            objUser.TEL_2 = txtTel2.Text.ToString();
            objUser.Status = ddlStatus.SelectedValue.ToString().ToLower();
            objUser.Logged = ddlLogged.SelectedValue.ToString().Trim();
            objUser.Collection_User = ddlColletionUser.SelectedValue.ToString().Trim();

            if (chkPassword.Checked)
                objUser.Password = "1";
            else
                objUser.Password = "0";


            objUser.Sim_IP = txtSimIp.Text.ToString();
            objUser.Printer_Serial_No = txtPrinterSerial.Text.ToString();
            objUser.Device_Type = ddlDeviceType.SelectedValue.ToString().Trim();
            objUser.Device_Brand = txtDeviceBrand.Text.ToString();
            objUser.Device_Own = ddlDeviceOwnership.SelectedValue.ToString().Trim();
            objUser.MPOS_Device_Issued = ddlMposUser.SelectedValue.ToString().Trim();
            objUser.MPOS_User_Id = txtMposUserId.Text.ToString();

            objUser.Last_Modified_user = Session["EMPID"].ToString();


            //---------Backend Call------------
            if (objUser.UpdUsers(objUser) > 0)
            {
                lblSucMessage.Text = "User editing successful!";
            }
            else
                lblSucMessage.Text = "User editing fail!";
        }
        catch (Exception)
        {            
            throw;
        }
    }
    protected void ddlDeviceOwnership_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
