﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class UserCreation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        { 
            if (Session["isRestrict"].Equals("YES"))
                {
                    Response.Redirect("~\\LogIn.aspx", true);
                    return;

                }

        }
        catch (Exception)
        {
            
            throw;
        }
    }


    protected void btnCreate_Click(object sender, EventArgs e)
    {
        try
        {
            lblMessage.Text = "";
            fillAgent();
            //-----------------Check So valid-----------------
            if (!isvalidSo())
            {
                lblSucMessage.Text = "Invalid SO code!";
                return;
            }
            //-----------------Check So in salesOne system-----------------
            if (isSalesOneUser())
            {
                lblSucMessage.Text = "User already exist in SalesOne system!";
                return;
            }
            //-----------------Check So in salesApp system-----------------
            if (isSalesAppUser())
            {
                lblSucMessage.Text = "User already exist in system!";
                return;
            }
            //---------Save Process------------
            clsUsers objUser = new clsUsers();
            objUser.SOCode = txtSoCode.Text.ToString().PadLeft(8, '0');
            objUser.IMEI = txtImei.Text.ToString();
            objUser.TEL_1 = txtTel1.Text.ToString();
            objUser.TEL_2 = txtTel2.Text.ToString();

            objUser.Sim_IP = txtSimIp.Text.ToString();
            objUser.Printer_Serial_No = txtPrinterSerial.Text.ToString();
            objUser.Device_Type = ddlDeviceType.SelectedValue.ToString().Trim();
            objUser.Device_Brand = txtDeviceBrand.Text.ToString();
            objUser.Device_Own = ddlDeviceOwnership.SelectedValue.ToString().Trim();
            objUser.MPOS_Device_Issued=ddlMposUser.SelectedValue.ToString().Trim();
            objUser.MPOS_User_Id = txtMposUserId.Text.ToString();

            objUser.Create_User = Session["EMPID"].ToString();
            objUser.Collection_User = ddlColletionUser.SelectedValue.ToString().Trim();
            
            if (objUser.InsUsers(objUser) > 0)
            {
                resetForm();
                lblSucMessage.Text = "User creation successful!";              
            }
            else
                lblSucMessage.Text = "User creation fail!";


        }
        catch (Exception)
        {

            throw;
        }
    }
    private void resetForm()
    {
        try
        {
            txtSoCode.Text = "";
            txtImei.Text = "";
            txtTel1.Text = "";
            txtTel2.Text = "";
            lblName.Text = "";
            txtSimIp.Text = "";
            txtDeviceBrand.Text = "";
            txtPrinterSerial.Text = "";
            ddlDeviceOwnership.SelectedIndex = 0;
            ddlDeviceType.SelectedIndex = 0;
            ddlMposUser.SelectedIndex = 0;
            txtMposUserId.Text = "";
            //lblBranch.Text = "";
            //lblSotype.Text = "";


        }
        catch (Exception)
        {
            
            throw;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            lblMessage.Text = "";
            fillAgent();
           
        }
        catch (Exception)
        {
            
            throw;
        }
    }

    private void fillAgent()
    {
        if (!string.IsNullOrEmpty(txtSoCode.Text.ToString()))
        {
            if (IsNumeric(txtSoCode.Text.ToString()))
            {
                clsUsers objUser = new clsUsers();
                DataSet dsAgents = new DataSet();
                dsAgents = objUser.GetAgents(txtSoCode.Text.ToString().Trim());
                if (dsAgents.Tables[0].Rows.Count > 0)
                {
                    string Name=dsAgents.Tables[0].Rows[0]["NAME"].ToString();
                    string Branch=dsAgents.Tables[0].Rows[0]["BRANCH"].ToString();
                     string Socat=dsAgents.Tables[0].Rows[0]["SOTYPE"].ToString();
                     lblName.Text = Name.Trim() + "(" + Socat + ")" + Branch.PadLeft(100) ;
                    //lblBranch.Text = 
                    //lblSotype.Text = 
                     if (isSalesAppUser())
                     {
                         lblMessage.Text = "User already exist in system!";
                         return;
                     }
                }
                else
                {
                    lblName.Text = "";
                    //lblBranch.Text = "";
                    //lblSotype.Text = "";
                    lblMessage.Text = "Can not find agent code!";
                    
                }
            }
        }
    }

    private bool isvalidSo()
    {
        clsUsers objUser = new clsUsers();
        DataSet dsAgents = new DataSet();
        dsAgents = objUser.GetAgents(txtSoCode.Text.ToString().Trim());
        if (dsAgents.Tables[0].Rows.Count > 0)
            return true;
        else
            return false;
    }
    private bool isSalesOneUser()
    {
                clsUsers objUser = new clsUsers();
                DataSet dsAgents = new DataSet();
                dsAgents = objUser.GetSalesOneUser(txtSoCode.Text.ToString().Trim());
                if (dsAgents.Tables[0].Rows.Count > 0)
                    return true;
                else
                    return false;
    }
    private bool isSalesAppUser()
    {
        clsUsers objUser = new clsUsers();
        DataSet dsAgents = new DataSet();
        dsAgents = objUser.GetSalesAppUser(txtSoCode.Text.ToString().Trim());
        if (dsAgents.Tables[0].Rows.Count > 0)
            return true;
        else
            return false;
    }
    private bool IsNumeric(String InputVal)
    {
        bool isdt = true;
        try
        {
            Double dt = Double.Parse(InputVal);
        }
        catch (Exception)
        {

            isdt = false;
        }
        return isdt;
    }
    protected void ddlDeviceOwnership_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtTel1_TextChanged(object sender, EventArgs e)
    {

    }
}
