﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class UserSearch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["isRestrict"].Equals("YES"))
                {
                    Response.Redirect("~\\LogIn.aspx", true);
                    return;
                }
        }
        catch (Exception)
        {
            
            throw;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            loadGrid(-1);
        }
        catch (Exception)
        {
            
            throw;
        }
    }
    private void loadGrid(int pageIndex)
    {
        try
        {

                clsUsers objUser = new clsUsers();
                DataSet dsUser = new DataSet();

            string Type="";
            if (radSo .Checked){Type="SO";}
            else if (radBranch .Checked){Type="BRANCH";}
            else if (radDataNo .Checked){Type="DATA";}
            else if (radImei.Checked) { Type = "IMEI"; }

            if (!string.IsNullOrEmpty(txtSoCode.Text.ToString()))
            {
                //if (IsNumeric(txtSoCode.Text.ToString()))
                //{

                dsUser = objUser.GetSearchUser(Type,txtSoCode.Text.ToString().Trim());
                //}
            }
            else
            {
                dsUser = objUser.GetUserDtl("-1");
            }

            if (dsUser.Tables.Count >0)
            {
                dgvUserDtl.DataSource = dsUser.Tables[0];
                dgvUserDtl.PageIndex = pageIndex > 0 ? pageIndex : 0;
                dgvUserDtl.DataBind();

                if (dsUser.Tables[0].Rows.Count == 0)
                {
                    lblMessage.Text = "Records not found!";
                }
            }

        }
        catch (Exception)
        {           
            throw;
        }
    }
    private bool IsNumeric(String InputVal)
    {
        bool isdt = true;
        try
        {
            Double dt = Double.Parse(InputVal);
        }
        catch (Exception)
        {

            isdt = false;
        }
        return isdt;
    }

    protected void dgvUserDtl_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
             loadGrid(e.NewPageIndex);
        }
        catch (Exception)
        {
            
            throw;
        }
    }
    protected void LinkButtonEdit_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btndetails = sender as LinkButton;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            LinkButton l = new LinkButton();
            l = (LinkButton)gvrow.FindControl("LinkButtonEdit");
            string PARTICIPANT_NO = l.CommandArgument.ToString();
            Session["SOCODE"] = PARTICIPANT_NO;
            Response.Redirect("~/UserEdit.aspx");
       //loadpanel();
       //ModalPopupExtender1.Show();
        }
        catch (Exception)
        {
            
            throw;
        }
       

    }
}
