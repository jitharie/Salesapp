﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ColletionsVerify : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                if (Session["isRestrict"].Equals("NO"))
                {
                    Response.Redirect("~\\LogIn.aspx", true);
                    return;
                }
                //Test case: Payment Method CSH/CQE
                //Session["socode"] = "00041924";
                //Session["cssno"] = "C000680";

                //Test case: Collection type Deposit/Renewal
                //Session["socode"] = "00041873";
                //Session["cssno"] = "C000501";

                //Test case: Collection type All
                //Session["socode"] = "00024794";
                //Session["cssno"] = "C000504";
                if (Session["UserType"].ToString().Equals("USER"))
                {
                    btnCancelTxn.Visible = false;
                }
                lblSoCode.Text = Session["socode"].ToString();
                lblCssNo.Text = Session["cssno"].ToString();
                loadBankCode();
                SetLastSyncDate();
                SetColletionTot();
                loadCashGrid(-1);
                loadChequeGrid(-1);
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    private void loadBankCode()
    {
        try
        { 
            GetData clsGetdata = new GetData();
            DataSet dsBank = null;

            dsBank = clsGetdata.getBank();
            ddlBank.DataSource = dsBank.Tables[0];
            ddlBank.DataTextField = "Bank_Name";
            ddlBank.DataValueField = "Bank_Code";
            ddlBank.DataBind();
            ListItem lst=new ListItem ("--Select--","");
            ddlBank.Items.Insert(0, lst);

        }
        catch (Exception)
        {
            throw;
        }
    }
    private void SetLastSyncDate()
    {
        try
        {
            string socode = Session["socode"].ToString();
            string cssno = Session["cssno"].ToString();
            clsCollection objclsCollection = new clsCollection();
            DataSet dsLastSync = new DataSet();

            dsLastSync = objclsCollection.GetLastSyncDtl(socode, cssno);

            if (dsLastSync.Tables[0].Rows.Count > 0)
            {
                lblLastSyncDate.Text = Convert.ToDateTime(dsLastSync.Tables[0].Rows[0][0].ToString()).Date.ToString("dd/MM/yyyy");
                lblLastSyncTime.Text = Convert.ToDateTime(dsLastSync.Tables[0].Rows[0][0].ToString()).TimeOfDay.ToString();
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    private void SetColletionTot()
    {
        try
        {
            string socode = Session["socode"].ToString();
            string cssno = Session["cssno"].ToString();
            clsCollection objclsCollection = new clsCollection();
            DataSet dsColletionTot = new DataSet();

            dsColletionTot = objclsCollection.GetCollectionTot(socode, cssno);

            if (dsColletionTot.Tables[0].Rows.Count > 0)
            {
                lblCashTotal.Text = "Total For Cash(Rs):" + Convert.ToDouble(dsColletionTot.Tables[0].Rows[0][0].ToString()).ToString("N2");
                lblChequeTotal.Text = "Total For Cheque(Rs):" + Convert.ToDouble(dsColletionTot.Tables[0].Rows[1][0].ToString()).ToString("N2");
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    private void loadCashGrid(int pageIndex)
    {
        try
        {
            lblMessage.Text = "";
            string socode = Session["socode"].ToString();
            string cssno = Session["cssno"].ToString();
            clsCollection objclsCollectionCash = new clsCollection();
            DataSet dsCollectionCash = new DataSet();

            dsCollectionCash = objclsCollectionCash.GetCollectionDtl("CSH", socode, cssno);


            if (dsCollectionCash.Tables.Count > 0)
            {
                dgvCash.DataSource = dsCollectionCash.Tables[0];
                dgvCash.PageIndex = pageIndex > 0 ? pageIndex : 0;
                dgvCash.DataBind();

                if (dsCollectionCash.Tables[0].Rows.Count == 0)
                {
                    lblMessage.Text = "Records not found!";
                }
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void dgvCash_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string ColType = e.Row.Cells[5].Text.ToString();


                if ((ColType == "Deposit") || (ColType == "Deposite"))
                {
                    e.Row.Cells[3].Enabled = false;
                }
                else if (ColType == "Loan")
                {
                    e.Row.Cells[2].Enabled = false;
                }
                else if (ColType == "Renewal")
                {
                    e.Row.Cells[2].Enabled = false;
                    e.Row.Cells[3].Enabled = false;
                }


            }
        }
        catch (Exception)
        {

            throw;
        }
    }


    private void loadChequeGrid(int pageIndex)
    {
        try
        {
            lblMessage.Text = "";
            string socode = Session["socode"].ToString();
            string cssno = Session["cssno"].ToString();
            clsCollection objclsCollectionCheque = new clsCollection();
            DataSet dsCollectionCheque = new DataSet();

            dsCollectionCheque = objclsCollectionCheque.GetCollectionDtl("CHQ", socode, cssno);


            if (dsCollectionCheque.Tables.Count > 0)
            {
                dgvCheque.DataSource = dsCollectionCheque.Tables[0];
                dgvCheque.PageIndex = pageIndex > 0 ? pageIndex : 0;
                dgvCheque.DataBind();

                if (dsCollectionCheque.Tables[0].Rows.Count == 0)
                {
                    if (dgvCash .Rows .Count ==0)
                    lblMessage.Text = "Records not found!";
                }
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void dgvCheque_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
              if (e.Row.RowType == DataControlRowType.DataRow)
                {
                            string ColType = e.Row.Cells[5].Text.ToString();
                            if ((ColType == "Deposit") || (ColType == "Deposite"))
                            {
                                e.Row.Cells[3].Enabled = false;
                            }
                            else if (ColType == "Loan")
                            {
                                e.Row.Cells[2].Enabled = false;
                            }
                            else if (ColType == "Renewal")
                            {
                                e.Row.Cells[2].Enabled = false;
                                e.Row.Cells[3].Enabled = false;
                            }

                }
        }
        catch (Exception)
        {
            
            throw;
        }
    }
    protected void btnVerify_Click(object sender, EventArgs e)
    {
        try
        {
                double recUpdateCnt = 0;
                string strSoCode = Session["SOCODE"].ToString();
                clsCollection objCollection = new clsCollection();
                objCollection.SOCode =strSoCode.PadLeft(8, '0');
                objCollection.VerifiedBy = Session["EMPID"].ToString();
            //---------------Cash Verify-----------------------------
            foreach (GridViewRow di in dgvCash.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chk");
                if (chkBx != null && chkBx.Checked)
                {

                    LinkButton tplReceiptNo = (LinkButton)di.FindControl("linkRctNo");
                    TextBox tplContractNo = (TextBox)di.FindControl("txtCONTRACTNO");
                    TextBox tplLoanInt = (TextBox)di.FindControl("txtLOANINT");
                    DropDownList tplBankState = (DropDownList)di.FindControl("ddlBANKSTATE");
                    TextBox tplRemarks = (TextBox)di.FindControl("txtREMARKS");

                    objCollection.ReceiptSeqNo = tplReceiptNo.Text.ToString();
                    objCollection.CollectionType = di.Cells[5].Text.ToString();
                    objCollection.ContractNo = tplContractNo.Text.ToString();
                    double LoanInt = 0;
                    if (!string.IsNullOrEmpty(tplLoanInt.Text))
                        LoanInt = Convert.ToDouble(tplLoanInt.Text.ToString());
                    objCollection.LoanInt = LoanInt;
                    objCollection.PaymentMethod = "CSH";
                    objCollection.ChequeNo = "";
                    objCollection.BankCode = "";
                    objCollection.BranchCode = "";
                    objCollection.BankState =tplBankState.Text.ToString();
                    objCollection.Remarks = tplRemarks.Text.ToString();
                    objCollection.TxnSt = ddlBank.SelectedValue.ToString().Trim();

                    //---------Backend Call------------
                    if (objCollection.UpdCollectionVerify(objCollection) > 0)
                        recUpdateCnt += 1;                  
                }
            }

            //---------------Cheque Verify-----------------------------
            foreach (GridViewRow di in dgvCheque.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chk");
                if (chkBx != null && chkBx.Checked)
                {
                    LinkButton tplReceiptNo = (LinkButton)di.FindControl("linkRctNo");
                    TextBox tplContractNo = (TextBox)di.FindControl("txtCONTRACTNO");
                    TextBox tplLoanInt = (TextBox)di.FindControl("txtLOANINT");
                    TextBox tplChequeNo = (TextBox)di.FindControl("txtCHEQUENO");
                    DropDownList tplBankState = (DropDownList)di.FindControl("ddlBANKSTATE");
                    TextBox tplRemarks = (TextBox)di.FindControl("txtREMARKS");

                    objCollection.ReceiptSeqNo = tplReceiptNo.Text.ToString();
                    objCollection.CollectionType = di.Cells[5].Text.ToString();
                    objCollection.ContractNo = tplContractNo.Text.ToString();
                    double LoanInt = 0;
                    if (!string.IsNullOrEmpty(tplLoanInt.Text))
                        LoanInt = Convert.ToDouble(tplLoanInt.Text.ToString());
                    objCollection.LoanInt = LoanInt;
                    objCollection.PaymentMethod = "CHQ";
                    objCollection.ChequeNo = tplChequeNo.Text.Trim().Substring(0, 6);
                    objCollection.BankCode = tplChequeNo.Text.Trim().Substring(7, 4);
                    objCollection.BranchCode = tplChequeNo.Text.Trim().Substring(12, 3);
                    objCollection.BankState = tplBankState.Text.ToString();
                    objCollection.Remarks = tplRemarks.Text.ToString();
                    objCollection.TxnSt = ddlBank.SelectedValue.ToString().Trim();

                    //---------Backend Call------------
                    if (objCollection.UpdCollectionVerify(objCollection) > 0)
                        recUpdateCnt += 1;
                }
            }
            double recTotalCnt = dgvCash.Rows.Count + dgvCheque.Rows.Count;
            if (recUpdateCnt == recTotalCnt)
            {
                Response.Redirect("~/Colletions.aspx", true);
            }
            else
            {
                loadCashGrid(-1);
                loadChequeGrid(-1);
                SetColletionTot();
                lblMessage.Text = recUpdateCnt.ToString() + " record/s verified!";
            }


        }
        catch (Exception)
        {
            
            throw;
        }
    }
    protected void btnCancelTxn_Click(object sender, EventArgs e)
    {
        try
        {
            double recUpdateCnt = 0;
            string strSoCode = Session["SOCODE"].ToString();
            clsCollection objCollection = new clsCollection();
            objCollection.SOCode = strSoCode.PadLeft(8, '0');
            objCollection.VerifiedBy = Session["EMPID"].ToString();
            //---------------Cash Verify-----------------------------
            foreach (GridViewRow di in dgvCash.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chk");
                if (chkBx != null && chkBx.Checked)
                {
                    LinkButton tplReceiptNo = (LinkButton)di.FindControl("linkRctNo");
                    objCollection.ReceiptSeqNo = tplReceiptNo.Text.ToString();
                    //---------Backend Call------------
                    if (objCollection.UpdCollectionCancelled(objCollection) > 0)
                        recUpdateCnt += 1;
                }
            }

            //---------------Cheque Verify-----------------------------
            foreach (GridViewRow di in dgvCheque.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chk");
                if (chkBx != null && chkBx.Checked)
                {
                    LinkButton tplReceiptNo = (LinkButton)di.FindControl("linkRctNo");
                    objCollection.ReceiptSeqNo = tplReceiptNo.Text.ToString();
                    //---------Backend Call------------
                    if (objCollection.UpdCollectionCancelled(objCollection) > 0)
                        recUpdateCnt += 1;
                }
            }
            double recTotalCnt = dgvCash.Rows.Count + dgvCheque.Rows.Count;
            if (recUpdateCnt == recTotalCnt)
            {
                Response.Redirect("~/Colletions.aspx", true);
            }
            else
            {
                loadCashGrid(-1);
                loadChequeGrid(-1);
                SetColletionTot();
                lblMessage.Text = recUpdateCnt.ToString() + " record/s cancelled!";
            }


        }
        catch (Exception)
        {

            throw;
        }
    }

    //protected void linkRctNo_Click(object sender, EventArgs e)
    //{
    //    LinkButton btndetails = sender as LinkButton;
    //    GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
    //    LinkButton lbtn = new LinkButton();
    //    lbtn = (LinkButton)gvrow.FindControl("linkRctNo");


    //    string strRctNo = lbtn.CommandArgument;
    //    string strSoCode = Session["SOCODE"].ToString().PadLeft(8, '0');

    //    clsCollection objCollection = new clsCollection();

    //    LoadReceiptpanel(strSoCode, strRctNo);
    //    this.ModalPopupExtender1.Show();

    //}

    //private void LoadReceiptpanel(string SoCode, string RctNo)
    //{
    //    try
    //    {

    //    }
    //    catch (Exception)
    //    {
            
    //        throw;
    //    }
    //}
}
