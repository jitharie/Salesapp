﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Enterprise;
using CrystalDecisions.Shared;


public partial class ColletionsReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            //if (Session["isRestrict"].Equals("NO"))
            //{
            //    Response.Redirect("~\\LogIn.aspx", true);
            //    return;
            //}
            if (!this.IsPostBack)
            {
                loadBranchCode();
                txtFromDate.Text = DateTime.Now.Date.ToString("yyyy-MM-dd");
                txtToDate.Text = DateTime.Now.Date.ToString("yyyy-MM-dd");
              
            }
        }
        catch (Exception)
        {           
            throw;
        }
    }

    private void loadBranchCode()
    {
        try
        {
            GetData clsGetdata = new GetData();
            DataSet dsBranch = null;

            if (Session["isRestrict"].ToString() == "NO")
            {
                dsBranch = clsGetdata.getAllBranch();
            }
            else
            {
                string EmpID = Session["EMPID"].ToString();
                dsBranch = clsGetdata.getUserBranch(EmpID);
            }

            ddlBranch.DataSource = dsBranch.Tables[0];
            ddlBranch.DataTextField = "BRANCH";
            ddlBranch.DataValueField = "BRANCH";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, "ALL");

        }
        catch (Exception)
        {
            throw;
        }
    }
 

    private string GetBranchString()
    {
        try
        {       string BranchStr = "";

            if (ddlBranch.SelectedValue.ToString() == "ALL")
            {               
                for (int i = 1; i < ddlBranch.Items.Count; i++)
                {
                    if (i==ddlBranch.Items.Count-1)
                        BranchStr+= "'"+ddlBranch.Items[i].Value.ToString()+"'";
                    else
                        BranchStr += "'" + ddlBranch.Items[i].Value.ToString() + "',"; ;
                }
            }
            else
            {
                BranchStr = "'" + ddlBranch.SelectedValue.ToString() + "'";
            }
            return BranchStr;
        }
        catch (Exception)
        {           
            throw;
        }
    }
    int DaysBetween(DateTime d1, DateTime d2)
    {
        TimeSpan span = d2.Subtract(d1);
        return (int)span.TotalDays;
    }

    protected void btnView_Click(object sender, EventArgs e)
    {

        try
        {
            lblMessage.Text = "";
            clsCollection objclsCollectionCash = new clsCollection();
            string Type = ddlType.SelectedValue.ToString();
             string branch = ddlBranch.SelectedValue.ToString();
             string frmDate = Convert.ToDateTime(txtFromDate.Text.Trim()).ToString("yyyy-MM-dd");
             string toDate = Convert.ToDateTime(txtToDate.Text.Trim()).ToString("yyyy-MM-dd");

             if (DaysBetween(Convert.ToDateTime(txtFromDate.Text.Trim()), Convert.ToDateTime(txtToDate.Text.Trim())) > 3)
             {
                 lblMessage.Text = "Invalid date range.Maximum date range:3days";
                 return;
             }

             System.Data.DataTable _temptable = objclsCollectionCash.GetCollectionVerifyReport(Type,GetBranchString(), frmDate, toDate);
             if (_temptable.Rows.Count == 0)
             {
                 lblMessage.Text = "No records found!";
                 return;
             }
             ReportDocument myReport = new ReportDocument();
             myReport.Load(Server.MapPath("RptCollection.rpt"));
             
             //myReport.ParameterFields["@Type"].CurrentValues.Add(Type); 
             myReport.SetDataSource(_temptable);
            myReport.SetParameterValue("RptType", Type);
            myReport.SetParameterValue("BranchCd", branch);
            myReport.SetParameterValue("frDate", frmDate);
            myReport.SetParameterValue("tDate", toDate);

            string RptString = branch + Type;

            myReport.ExportToDisk(ExportFormatType.PortableDocFormat, Server.MapPath("files/" + RptString + ".pdf"));
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), Guid.NewGuid().ToString(), "var popup=window.open('files/"+ RptString +".pdf');popup.focus(); ", true);
            ScriptManager.RegisterStartupScript(this, this.GetType(), Guid.NewGuid().ToString(), "var popup=window.open('files/" + RptString + ".pdf');popup.focus(); ", true);

           
            }


        catch (Exception)
        {
            
            throw;
        }

  
   
}
    protected void button_Click(object sender, EventArgs e)
    {
        // open a pop up window at the center of the page.
        ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", "var Mleft = (screen.width/2)-(760/2);var Mtop = (screen.height/2)-(700/2);window.open( 'your_page.aspx', null, 'height=700,width=760,status=yes,toolbar=no,scrollbars=yes,menubar=no,location=no,top=\'+Mtop+\', left=\'+Mleft+\'' );", true);
    }

}
