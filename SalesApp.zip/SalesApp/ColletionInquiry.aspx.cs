﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ColletionInquiry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                loadBranchCode();
                loadSoCode();
            }
        }
        catch (Exception)
        {
            
            throw;
        }
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
             loadSoCode();
        }
        catch (Exception)
        {           
            throw;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dgvDetails.DataSource = null;
            dgvDetails.DataBind();
            lblSoCode.Text = "";
            lblCssNo.Text = "";
            loadData(-1);
        }
        catch (Exception)
        {
            
            throw;
        }
    }
    protected void dgvSummary_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            loadData(e.NewPageIndex);
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void LinkButtonDetail_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btndetails = sender as LinkButton;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            LinkButton l = new LinkButton();
            l = (LinkButton)gvrow.FindControl("linkButtonDetail");

            string info = l.CommandArgument;
            string[] arg = new string[2];
            char[] splitter = { ';' };
            arg = info.Split(splitter);
            string socode = arg[0];
            string cssno = arg[1];
            Session["socode"] = socode;
            //Session["cssno"] = cssno;
            loadDetailGrid(-1, socode, cssno);
            //Response.Redirect("~/ColletionsVerify.aspx", true);

        }
        catch (Exception)
        {

            throw;
        }
    }
    private void loadDetailGrid(int pageIndex, string socode,  string cssno )
    {
        try
        {
            lblSoCode.Text ="SO Code: "+ socode;
            lblCssNo.Text ="CSS No: "+cssno;
            lblMessage.Text = "";
            clsCollection objclsCollectionCash = new clsCollection();
            DataSet dsCollectionDtl = new DataSet();

            dsCollectionDtl = objclsCollectionCash.GetCollectionInquiryDtl(socode, cssno);


            if (dsCollectionDtl.Tables.Count > 0)
            {
                dgvDetails.DataSource = dsCollectionDtl.Tables[0];
                dgvDetails.PageIndex = pageIndex > 0 ? pageIndex : 0;
                dgvDetails.DataBind();

                if (dsCollectionDtl.Tables[0].Rows.Count == 0)
                {
                    lblMessage.Text = "Records not found!";
                }
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    private void loadBranchCode()
    {
        try
        {
            GetData clsGetdata = new GetData();
            DataSet dsBranch = null;

            if (Session["isRestrict"].ToString() == "NO")
            {
                dsBranch = clsGetdata.getAllBranch();
            }
            else
            {
                string EmpID = Session["EMPID"].ToString();
                dsBranch = clsGetdata.getUserBranch(EmpID);
            }
           
            ddlBranch.DataSource = dsBranch.Tables[0];
            ddlBranch.DataTextField = "BRANCH";
            ddlBranch.DataValueField = "BRANCH";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, "ALL");

        }
        catch (Exception)
        {
            throw;
        }
    }
    private void loadSoCode()
    {
        try
        {
            string branchCode = ddlBranch.SelectedValue.ToString();

            GetData clsGetdata = new GetData();
            DataSet dsSo = null;

            if (branchCode != "ALL")
            {
                dsSo = clsGetdata.getSoByBranch(branchCode);
            }
            else
            {

                if (Session["isRestrict"].ToString() == "NO")
                {
                    dsSo = clsGetdata.getAllSo();
                }
                else
                {
                    string BranchCodeStr = GetBranchString();
                    dsSo = clsGetdata.getAllSoByBranchStr(BranchCodeStr);
                }
            }

            ddlSoCode.DataSource = dsSo.Tables[0];
            ddlSoCode.DataTextField = "SOCODE";
            ddlSoCode.DataValueField = "SOCODE";
            ddlSoCode.DataBind();
            ddlSoCode.Items.Insert(0, "ALL");

        }
        catch (Exception)
        {
            throw;
        }
    }
    private string GetBranchString()
    {
        try
        {
            string BranchStr = "";

            if (ddlBranch.SelectedValue.ToString() == "ALL")
            {
                for (int i = 1; i < ddlBranch.Items.Count; i++)
                {
                    if (i == ddlBranch.Items.Count - 1)
                        BranchStr += "'" + ddlBranch.Items[i].Value.ToString() + "'";
                    else
                        BranchStr += "'" + ddlBranch.Items[i].Value.ToString() + "',"; 
                }
            }
            else
            {
                BranchStr = "'" + ddlBranch.SelectedValue.ToString() + "'";
            }
            return BranchStr;
        }
        catch (Exception)
        {
            throw;
        }
    }
    private void loadData(int pageIndex)
    {
        try
        {
            lblMessage.Text = "";
            string EmpID = Session["EMPID"].ToString();

            clsCollection objclsCollection = new clsCollection();
            DataSet dsCollection = new DataSet();
            //string brCode = GetBranchString();
            string branchCode = ddlBranch.SelectedValue.ToString();
            string SoCode = ddlSoCode.SelectedValue.ToString();
            string ColletionStatus = ddlStatus.SelectedValue.ToString();

            string BranchCodeStr = "";
            if (Session["isRestrict"].ToString() == "NO")
                BranchCodeStr = "";
            else
                 BranchCodeStr = GetBranchString();


            dsCollection = objclsCollection.GetCollectionInquiry(branchCode, SoCode, ColletionStatus, txtCssNo.Text.ToString(), BranchCodeStr);


            if (dsCollection.Tables.Count > 0)
            {
                dgvSummary.DataSource = dsCollection.Tables[0];
                dgvSummary.PageIndex = pageIndex > 0 ? pageIndex : 0;
                dgvSummary.DataBind();

                if (dsCollection.Tables[0].Rows.Count == 0)
                {
                    lblMessage.Text = "Records not found!";
                }
            }

        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void dgvSummary_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }
}
