﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ReceiptDatails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
              string SoCode = Session["socode"].ToString();
              string RctNo = Request.QueryString[0];

              clsCollection objclsCollection = new clsCollection();
              DataSet dsRctDtl = new DataSet();

              dsRctDtl = objclsCollection.GetRctDtl(SoCode, RctNo);

              if (dsRctDtl.Tables[0].Rows.Count > 0)
              {
                  
                  lblHeading1.Text = dsRctDtl.Tables[0].Rows [0]["CollectionType"].ToString()+" Collection Temporary Receipt";
                  lblHeading2.Text = SoCode + "-" + RctNo;
                  lblNic.Text = dsRctDtl.Tables[0].Rows[0]["CustomerIDNo"].ToString();
                  lblName.Text = dsRctDtl.Tables[0].Rows[0]["CustomerName"].ToString();
                  lblClientNo.Text = dsRctDtl.Tables[0].Rows[0]["CustomerId"].ToString();
                  lblPaymentMethod.Text = dsRctDtl.Tables[0].Rows[0]["PaymentMethod"].ToString();
                  lblColletionAmt.Text = Convert.ToDouble(dsRctDtl.Tables[0].Rows[0]["CollectionAmt"].ToString()).ToString("N0");                   
                  lblDateTime.Text = dsRctDtl.Tables[0].Rows[0]["CSSCreatedDate"].ToString();
                  lblAgentName.Text = dsRctDtl.Tables[0].Rows[0]["AgentName"].ToString();
                  lblAddress.Text = dsRctDtl.Tables[0].Rows[0]["Address"].ToString();

              }
            }

        }
        catch (Exception)
        {
            
            throw;
        }
    }
}
